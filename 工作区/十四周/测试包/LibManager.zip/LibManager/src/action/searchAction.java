package action;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import util.DBUtils;


import bean.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class searchAction extends ActionSupport{
	
	private String identity;
	private String username;	
	
	public String getIdentity(){
		return identity;
	}
	public void setIdentity(String identity){
		this.identity=identity;
	}
	public String getUsername(){
		return username;
	}
	public void setUsername(String username){
		this.username=username;
	}
	
	public String execute() throws Exception{
		HttpServletRequest request=(HttpServletRequest)ActionContext.getContext().get(ServletActionContext.HTTP_REQUEST);
		
		if(identity.equals("admin"))
		{
			User user=new User();
			/*
			user.setUsername("Admin");
			user.setPassword("admin");
			user.setName("������");
			user.setBirthday("1994.06.12");
			user.setTeacherTitle(null);
			user.setMajor(null);
			user.setId(null);
			user.setIdentity("����Ա");
			user.setAddress(null);
			*/
			
			
			//TODO Get Admin'Username;
			//TODO User userInfo(String username);�ҳ����û�����ͬ���û�������Ϣ
			user=DBUtils.getUser(username);
			if(user.getUsername().equals("admin"))
			{
				
				
				request.getSession().setAttribute("User", user);
				
				return SUCCESS;
			}else{
				return "fail";
			}
		}
		else if(identity.equals("teacher"))
		{
			User user=new User();
			/*
			user.setUsername("teacher");
			user.setPassword("teacher");
			user.setName("������");
			user.setBirthday("1994.06.12");
			user.setTeacherTitle("����");
			user.setMajor("���������");
			user.setId("12080113");
			user.setIdentity("��ʦ");
			user.setAddress("������ҵ��ѧ");
			*/
			//TODO Get teacher'Username;
			//TODO user userInfo(String username);�ҳ����û�����ͬ���û�������Ϣ
			user=DBUtils.getUser(username);
			if(user.getUsername().equals("teacher"))
			{
				
				request.getSession().setAttribute("User", user);
				
				return SUCCESS;
			}else{
				return "fail";
			}
		}
		else if(identity.equals("student"))
		{
			User user=new User();
			/*
			user.setUsername("student");
			user.setPassword("student");
			user.setName("������");
			user.setBirthday("1994.06.12");
			user.setTeacherTitle(null);
			user.setMajor("���������");
			user.setId("12080113");
			user.setIdentity("ѧ��");
			user.setAddress("������ҵ��ѧ");
			*/
			//TODO Get Student'Username;
			//TODO User userInfo(String username);�ҳ����û�����ͬ���û�������Ϣ
			user=DBUtils.getUser(username);
			if(user.getUsername().equals("student"))
			{
				
				request.getSession().setAttribute("User", user);
				
				return SUCCESS;
			}else{
				return "fail";
			}
		}
		else if(identity.equals("otherpeople"))
		{
			User user=new User();
			/*
			user.setUsername("otherpeople");
			user.setPassword("otherpeople");
			user.setName("������");
			user.setBirthday("1994.06.12");
			user.setTeacherTitle(null);
			user.setMajor(null);
			user.setId(null);
			user.setIdentity("У����Ա");
			user.setAddress("������ҵ��ѧ");
			*/
			//TODO Get Otherpeople'Username;
			//TODO void userInfo(String username);�ҳ����û�����ͬ���û�������Ϣ
			user=DBUtils.getUser(username);
			if(username.equals("otherpeople"))
			{
				
				request.getSession().setAttribute("User", user);
				
				
				return SUCCESS;
			}else{
				return "fail";
			}
		}else{
			return "fail";
		}
		
	}
}
