package action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;


import org.apache.catalina.Session;
import org.apache.struts2.ServletActionContext;

import util.DBUtils;

import bean.Record;
import bean.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;



public class ModifyUserAction extends ActionSupport {
	private String username;
	private String age;
	private String password;
	private String birthday;
	private String address;
	
	
	public String modifyPassword(){
		//TODO 数据库修改密码
		System.out.println("passwordSuccess"+password);
		//TODO修改密码，String username ,String password
		//    return 
		DBUtils.modifyUserPassword(username,password);
		
		return SUCCESS;
		
	}
	public String toModifyPassword(){
		return SUCCESS;
	}
	public String modifyName(){
		Boolean has=false;
		// 用户是否存在   String username 用户名
		//如果存在，输出真，否则输出假
		HttpServletRequest request=(HttpServletRequest)ActionContext.getContext().get(ServletActionContext.HTTP_REQUEST);
	    User user=(User)request.getSession().getAttribute("User");
	    
		has=DBUtils.IsExist(username);
		if(!has){
			//TODO  修改数据库中的UserName
			// @param String username 修改后的名字 ,String user 实际的名字
			System.out.println("ModifyNamesuccess"+username);
			DBUtils.modifyUsername(user.getName(),username);
			return SUCCESS;
		}else{
			return "failed";
		}
		
	}
	public String toModifyName(){
		User user=new User();
		//DBUtils.getUser(Session.get("User"));
		//User user=DBUtils.getUser("bob");
		HttpServletRequest request=(HttpServletRequest)ActionContext.getContext().get(ServletActionContext.HTTP_REQUEST);
	     user=(User)request.getSession().getAttribute("User");
	     String username=user.getUsername();
		//TODO  获取用户的所有信息
		
		 User user2=DBUtils.getUser(username);
		
		
		ServletActionContext.getRequest().setAttribute("username", user2.getUsername());
		return SUCCESS;
	}
	public String toEditInfo(){
		HttpServletRequest request=(HttpServletRequest)ActionContext.getContext().get(ServletActionContext.HTTP_REQUEST);
	     User user3=(User)request.getSession().getAttribute("User");
		User user=new User();
		 user=DBUtils.getUser(user3.getUsername());
		ServletActionContext.getRequest().setAttribute("user", user);
		return SUCCESS;
	}
	public String editInfo(){
		System.out.println(age);
		if(birthday.equals("")||address.equals("")){
			return "Failed";
		}else{
			System.out.println("SuccessEditInfo"+birthday+address);
			return SUCCESS;
		}
		
	}
	public String borrowReturn(){
		List<Record> records=new ArrayList<Record>();
		Record re=new Record();
		
		re.setBookName("闄堝叏淇濆偦閫");
		re.setState("Ok");
		re.setTime(new Date().toGMTString());
		re.setUsername("鍙插崥鏂");
		records.add(re);
		
		Record re2=new Record();
		re2.setBookName("涓夊疂");
		re2.setState("1111");
		re2.setTime(new Date().toGMTString());
		re2.setUsername("澶忔鏋");
		records.add(re2);
		//TODO 获取借书记录
		HttpServletRequest request=(HttpServletRequest)ActionContext.getContext().get(ServletActionContext.HTTP_REQUEST);
	     User user4=(User)request.getSession().getAttribute("User");
		  //TODO获取借书的所有信息
		ServletActionContext.getRequest().setAttribute("records",records );
		return SUCCESS;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
