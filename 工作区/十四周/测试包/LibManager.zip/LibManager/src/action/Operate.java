package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import util.DBUtils;

import com.opensymphony.xwork2.ActionContext;

import bean.Book;
import bean.Record;
import bean.User;

public class Operate {
	public String operate;
	
	public String getOperate() {
		return operate;
	}

	public void setOperate(String operate) {
		this.operate = operate;
	}

	public String execute(){
		HttpServletRequest request=(HttpServletRequest)ActionContext.getContext().get(ServletActionContext.HTTP_REQUEST);
		
		ArrayList<Book> books=new ArrayList<Book>();
		Book book=new Book();
		book.setBookName("JAVA");
		book.setBookState(1);
		
		Book book2=new Book();
		book.setBookName("php");
		book.setBookState(1);
		
		books.add(book);
		books.add(book2);
		
		if(operate!=null&&operate.equals("borrow")){
			//TODO ��ȡ���е��鱾���֣�����״̬��   
			//books �鱾������Ϣ
			 books=DBUtils.getAllBookInfo();
			//request ��ȡֵ
			
			System.out.println(books.toString());
		
			request.setAttribute("bookList", books);
			
			return "borrow";
		}else if(operate!=null&&operate.equals("return")){
			String name=(String)request.getSession().getAttribute("User");
			//TODO ͨ�����ֲ������н���ļ�¼
			//@param name  ����������
			//return     �����¼
			
			ArrayList<Record> records=new ArrayList<Record>();
			records=DBUtils.getAllRecord(name);
			request.setAttribute("records", records);
			return "return";
		}
		else if(operate!=null&&operate.equals("change")){
			String bookName=request.getParameter("bookName");
			//System.out.println("bookName="+bookName);
			Record record=new Record();
			record.setTime("2014-5-17");
			record.setBookName(bookName);
			record.setState("borrow");
			User user=(User)request.getSession().getAttribute("User");
			record.setUsername(user.getUsername());
			//TODO ����ı��鱾����״̬����state������һ��record�������ݿ�
			//@param String bookname �鱾��
			 DBUtils.saveRecord(record);
			
			
			return "success";
		}
		else if(operate!=null&&operate.equals("change2")){
			String bookName=request.getParameter("bookName");
			Record record=new Record();
			record.setTime("2014-5-17");
			record.setBookName(bookName);
			record.setState("return");
			User user2=(User)request.getSession().getAttribute("User");
			record.setUsername(user2.getUsername());
			//TODO �ı��鱾����״̬������һ��record�������ݿ�
			//@param String bookname �鱾��
			DBUtils.saveRecord(record);
			
			
			return "success2";
		}
		return "";
	}
}
