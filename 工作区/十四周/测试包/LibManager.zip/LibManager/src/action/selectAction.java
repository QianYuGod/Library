package action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;


import bean.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class selectAction extends ActionSupport{
	HttpServletRequest request=(HttpServletRequest)ActionContext.getContext().get(ServletActionContext.HTTP_REQUEST);
	
	private String select;
	
	User user=new User();
	
	
	public String execute() throws Exception{
		if(select.equals("userSearch")){
			return "user_search";
		}
		else if(select.equals("userModify")){
			return "user_modify";
		}else if(select.equals("userDelete")){
			List<String> namelist = new ArrayList<String>();
			//TODO ȡ����Ա����
			//�γ�һ��namelist��userDelete����ʾ������
			
			/*
			namelist.add("A");
			namelist.add("B");
			namelist.add("C");
			*/
			request.getSession().setAttribute("Namelist", namelist);
			return "user_delete";
		}else
			return "fail";
	}

	
	public String getSelect() {
		return select;
	}

	public void setSelect(String select) {
		this.select = select;
	}
	
}
